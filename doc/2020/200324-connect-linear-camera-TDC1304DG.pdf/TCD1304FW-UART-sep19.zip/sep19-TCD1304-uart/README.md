The TCD1304-driver firmware for STM32F401re.

Documentation can be found at:
https://tcd1304.wordpress.com/


Licenses:
	Everything, compiled or in source code, is under the FreeBSD-license.
	To cite the project write:
		Esben Rossel, (2017). The linear CCD-module [Firmware]
