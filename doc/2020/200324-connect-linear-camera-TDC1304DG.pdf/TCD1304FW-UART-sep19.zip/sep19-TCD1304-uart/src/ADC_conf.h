void ADC1_conf(void);
