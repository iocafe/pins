# I2S ADC scanning Example

Please replace rtc_module.c under $IDF_PATH/components/driver/.